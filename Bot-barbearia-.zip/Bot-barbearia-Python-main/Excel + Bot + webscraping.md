	
Excel:
1. criar planilha de gestão da barbearia

scrapping:
1. puxar dados da planilha excel como requisitado no bot

bot:
1. roda o whatsapp
2. localiza mensagens apenas de Dvison e Tiago
4. pergunta o que { nome } quer
5. Agendar cortes pagos
[ 1 ] Barbeiro:
[ 2 ] Valor:


[ esse bot irá puxar dados da planilha dentro da pasta do bot]
