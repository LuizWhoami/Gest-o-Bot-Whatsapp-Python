import csv

nome12 = ['dvison']
lis =['20']

with open('nome.csv', 'w', newline='') as csvfile1:
  
    preços = [
                        ['25'],
                        ['20'],
                        ['35'],
                        ['30'],
                        ['5'],
                        ['10']
                    ]
    
    print(next(preços))