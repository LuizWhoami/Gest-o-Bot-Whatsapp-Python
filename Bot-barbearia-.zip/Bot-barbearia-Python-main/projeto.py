from selenium import webdriver
from selenium.webdriver.common.by import By
from time import sleep
import requests
from selenium.webdriver.chrome.options import Options
from selenium.webdriver import Keys, ActionChains
import os
import pyautogui
import pandas as pd
import pyperclip
import csv
import sqlite3
#sudo apt-get install xclip
# sudo xhost +SI:localuser:luiz

agent = {"User-Agent": 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36'}
api = requests.get("https://editacodigo.com.br/index/api-whatsapp/C0JCTUr8erzNuCmSF0KrNCJD68hJv8xg" ,  headers=agent)
api = api.text
api = api.split(".n.")
msg_cliente = api[6].strip()

dir_path = os.getcwd()
chrome_options2 = Options()
chrome_options2.add_argument(r"user-data-dir=" + dir_path + "/pasta/sessao")
driver = webdriver.Chrome(chrome_options2)
driver.get('https://web.whatsapp.com/')
sleep(35)

driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div[2]/div[3]/div/div[1]/div/div[2]/div[2]/div/div/p').click()
nome12 = ['Dvison']
pyautogui.write(nome12[0])
pyautogui.hotkey('Enter')

pyautogui.write("*#### -- BARBEARIA LS -- ####*")
pyautogui.hotkey('Shift', 'Enter')
pyautogui.write("Ola Admin *{}*".format(nome12[0]))
pyautogui.hotkey('Shift', 'Enter')
pyautogui.write("*(1)* Armazenar  Corte")
pyautogui.hotkey('Shift', 'Enter')
pyautogui.write("*(2)* Verificar Cortes (construção)")
pyautogui.hotkey('Enter')

sleep(2)
def bot1():
    try:
        sleep(1)
        msg = driver.find_elements(By.CLASS_NAME, msg_cliente)
        msg = [e.text for e in msg]
        men = msg[-1]
        print(men)
        sleep(2)
        df = pd.DataFrame({men})
        df.to_csv('salvo.csv', index=False)
        with open('salvo.csv', 'r', newline='', encoding='utf-8') as arquivo:
            leitor = csv.reader(arquivo)
            next(leitor)
            for row in leitor:   
                if row == ['1']:
                    pyautogui.write("*Qual o Valor?*")
                    pyautogui.hotkey('Enter')
                if row == ['25']:
                    for conn in range(1):
                        nome = nome12
                        conn = sqlite3.connect("gestao.db")
                        cursor = conn.cursor()
                        cursor.executemany("INSERT INTO clientes (nome, valor) VALUES (?,?)", zip(nome, row))
                        conn.commit()
                        conn.close()
                        pyautogui.write("_Armazenado_")
                        pyautogui.hotkey('Enter')
                        sleep(2)
                        
                        pyautogui.write('_Para inserir outro valor_')
                        pyautogui.hotkey('Shift', 'Enter')
                        pyautogui.write('*(1)* _Inserir_')
                        pyautogui.hotkey('Enter')
                        if row == 1:
                            return(bot1())
                if row == ['30']:
                    for conn in range(1):
                        nome = nome12
                        conn = sqlite3.connect("gestao.db")
                        cursor = conn.cursor()
                        cursor.executemany("INSERT INTO clientes (nome, valor) VALUES (?,?)", zip(nome, row))
                        conn.commit()
                        conn.close()
                        pyautogui.write("_Armazenado_")
                        pyautogui.hotkey('Enter')
                        sleep(2)
                        
                        pyautogui.write('_Para inserir outro valor_')
                        pyautogui.hotkey('Shift', 'Enter')
                        pyautogui.write('*(1)* _Inserir_')
                        pyautogui.hotkey('Enter')
                        if row == 1:
                            return(bot1())
                if row == ['15']:
                    for conn in range(1):
                        nome = nome12
                        conn = sqlite3.connect("gestao.db")
                        cursor = conn.cursor()
                        cursor.executemany("INSERT INTO clientes (nome, valor) VALUES (?,?)", zip(nome, row))
                        conn.commit()
                        conn.close()
                        pyautogui.write("_Armazenado_")
                        pyautogui.hotkey('Enter')
                        sleep(2)
                        
                        pyautogui.write('_Para inserir outro valor_')
                        pyautogui.hotkey('Shift', 'Enter')
                        pyautogui.write('*(1)* _Inserir_')
                        pyautogui.hotkey('Enter')
                        if row == 1:
                            return(bot1())
                if row == ['10']:
                    for conn in range(1):
                        nome = nome12
                        conn = sqlite3.connect("gestao.db")
                        cursor = conn.cursor()
                        cursor.executemany("INSERT INTO clientes (nome, valor) VALUES (?,?)", zip(nome, row))
                        conn.commit()
                        conn.close()
                        pyautogui.write("_Armazenado_")
                        pyautogui.hotkey('Enter')
                        sleep(2)
                        
                        pyautogui.write('_Para inserir outro valor_')
                        pyautogui.hotkey('Shift', 'Enter')
                        pyautogui.write('*(1)* _Inserir_')
                        pyautogui.hotkey('Enter')
                        if row == 1:
                            return(bot1())       
                if row == ['80']:
                    for conn in range(1):
                        nome = nome12
                        conn = sqlite3.connect("gestao.db")
                        cursor = conn.cursor()
                        cursor.executemany("INSERT INTO clientes (nome, valor) VALUES (?,?)", zip(nome, row))
                        conn.commit()
                        conn.close()
                        pyautogui.write("_Armazenado_")
                        pyautogui.hotkey('Enter')
                        sleep(2)
                        
                        pyautogui.write('_Para inserir outro valor_')
                        pyautogui.hotkey('Shift', 'Enter')
                        pyautogui.write('*(1)* _Inserir_')
                        pyautogui.hotkey('Enter')
                        if row == 1:
                            return(bot1())
                if row == ['5']:
                    for conn in range(1):
                        nome = nome12
                        conn = sqlite3.connect("gestao.db")
                        cursor = conn.cursor()
                        cursor.executemany("INSERT INTO clientes (nome, valor) VALUES (?,?)", zip(nome, row))
                        conn.commit()
                        conn.close()
                        pyautogui.write("_Armazenado_")
                        pyautogui.hotkey('Enter')
                        sleep(2)
                        
                        pyautogui.write('_Para inserir outro valor_')
                        pyautogui.hotkey('Shift', 'Enter')
                        pyautogui.write('*(1)* _Inserir_')
                        pyautogui.hotkey('Enter')
                        if row == 1:
                            return(bot1())
                if row == ['20']:
                    for conn in range(1):
                        nome = nome12
                        conn = sqlite3.connect("gestao.db")
                        cursor = conn.cursor()
                        cursor.executemany("INSERT INTO clientes (nome, valor) VALUES (?,?)", zip(nome, row))
                        conn.commit()
                        conn.close()
                        pyautogui.write("_Armazenado_")
                        pyautogui.hotkey('Enter')
                        sleep(2)
                        
                        pyautogui.write('_Para inserir outro valor_')
                        pyautogui.hotkey('Shift', 'Enter')
                        pyautogui.write('*(1)* _Inserir_')
                        pyautogui.hotkey('Enter')
                        if row == 1:
                            return(bot1())
                def começa():
                    if row == ['2']:
                        conn = sqlite3.connect('gestao.db')
                        df = pd.read_sql_query("SELECT * FROM clientes", conn)
                        df.to_string('teste.csv', index=False)
                        conn.close()
                começa()
                    

    except:
        print('procurando mensagens')

while True:
    bot1()